#!/bin/bash
parent_path=$( cd "$(dirname "${BASH_SOURCE[0]}")" ; pwd -P )
cd "$parent_path/allure/allure-2.15.0/bin/"
bash allure open "$parent_path/allure-report"
exit